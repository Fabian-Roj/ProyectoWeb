from django.shortcuts import render
from .models import Producto
# Create your views here.
def producto_lista(request):
    productos = Producto.objects.select_related('categoria').all()
    contexto = {'productos': productos}
    return render(request, 'catalogo/lista.html', contexto)

